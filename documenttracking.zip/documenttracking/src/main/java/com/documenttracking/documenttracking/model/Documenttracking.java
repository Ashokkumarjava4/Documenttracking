public class Documenttracking {
    private String documentname;
    private String documenttype;
    private long versiondate;

    public Documenttracking(String documentname, String documenttype, long versiondate) {
        this.documentname = documentname;
        this.documenttype = documenttype;
        this.versiondate = versiondate;
    }

    public String getDocumentname() {
        return documentname;
    }

    public void setDocumentname(String documentname) {
        this.documentname = documentname;
    }

    public String getDocumenttype() {
        return documenttype;
    }

    public void setDocumenttype(String documenttype) {
        this.documenttype = documenttype;
    }

    public long getVersiondate() {
        return versiondate;
    }

    public void setVersiondate(long versiondate) {
        this.versiondate = versiondate;
    }
}
