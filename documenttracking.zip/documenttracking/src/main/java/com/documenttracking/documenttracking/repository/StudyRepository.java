import org.springframework.stereotype.Repository;

@Repository
public interface StudyRepository {
    studymanagement findbyname(String studyname);
}
