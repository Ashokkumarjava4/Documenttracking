import org.springframework.stereotype.Repository;

@Repository
public interface DocumentRepository {

    Documenttracking findByname(String documentname);
}
