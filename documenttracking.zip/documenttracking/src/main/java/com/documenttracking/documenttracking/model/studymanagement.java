public class studymanagement {
    private String studyname;
    private long uuid;
    private long code;

    public studymanagement(String studyname, long uuid, long code) {
        this.studyname = studyname;
        this.uuid = uuid;
        this.code = code;
    }

    public String getStudyname() {
        return studyname;
    }

    public void setStudyname(String studyname) {
        this.studyname = studyname;
    }

    public long getUuid() {
        return uuid;
    }

    public void setUuid(long uuid) {
        this.uuid = uuid;
    }

    public long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "studymanagement{" +
                "studyname='" + studyname + '\'' +
                ", uuid=" + uuid +
                ", code=" + code +
                '}';
    }
}
